﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_2
{
    public partial class Студенты : Form
    {
        private Студенты_табличная form3;
        public Студенты()
        {
            InitializeComponent();
        }

        private void студентBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.студентBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.успеваемостьDataSet);

        }

        private void Студенты_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "успеваемостьDataSet.Студент". При необходимости она может быть перемещена или удалена.
            this.студентTableAdapter.Fill(this.успеваемостьDataSet.Студент);

        }
        private void button1_Click(object sender, EventArgs e)
        {
            студентBindingSource.MoveFirst();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            студентBindingSource.MovePrevious();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            студентBindingSource.MoveNext();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            студентBindingSource.MoveLast();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            студентBindingSource.AddNew();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            студентBindingSource.RemoveCurrent();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.студентBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.успеваемостьDataSet);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            form3 = new Студенты_табличная();
            form3.Visible = true;
        }
    }
}
