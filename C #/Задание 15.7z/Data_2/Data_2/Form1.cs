﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_2
{
    public partial class Form1 : Form
    {
        private Студенты form2;
        private Предметы form4;
        private Ведомость form5;
        public Form1()
        {
            InitializeComponent();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            form2 = new Студенты();
            form2.Visible = true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            form4 = new Предметы();
            form4.Visible = true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            form5 = new Ведомость();
            form5.Visible = true;
        }
    }
}
