﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_2
{
    public partial class Студенты_табличная : Form
    {
        public Студенты_табличная()
        {
            InitializeComponent();
        }

        private void студентBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.студентBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.успеваемостьDataSet);

        }

        private void Студенты_табличная_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "успеваемостьDataSet.Студент". При необходимости она может быть перемещена или удалена.
            this.студентTableAdapter.Fill(this.успеваемостьDataSet.Студент);

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }
        private System.Windows.Forms.DataGridViewColumn COL;
        private void button1_Click(object sender, EventArgs e)
        {
            COL = new System.Windows.Forms.DataGridViewColumn();
            switch (listBox1.SelectedIndex)
            {
                case 0:
                    COL = dataGridViewTextBoxColumn2;
                    break;
                case 1:
                    COL = dataGridViewTextBoxColumn3;
                    break;
                case 2:
                    COL = dataGridViewTextBoxColumn4;
                    break;
            }
            if (radioButton1.Checked)
                студентDataGridView.Sort(COL, System.ComponentModel.ListSortDirection.Ascending);
            else
                студентDataGridView.Sort(COL, System.ComponentModel.ListSortDirection.Descending);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            студентBindingSource.Filter = "группа='" + comboBox1.Text + "'";
        }
        private void button3_Click(object sender, EventArgs e)
        {
            студентBindingSource.Filter = "";
        }
        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < студентDataGridView.Columns.Count - 1; i++)
            {
                for (int j = 0; j < студентDataGridView.RowCount - 1; j++)
                {
                    студентDataGridView[i, j].Style.BackColor = Color.White;
                    студентDataGridView[i, j].Style.ForeColor = Color.Black;
                }
            }
            for (int i = 0; i < студентDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < студентDataGridView.RowCount - 1; j++)
                {
                    if (студентDataGridView[i, j].Value.ToString().IndexOf(textBox1.Text) != -1)
                    {
                        студентDataGridView[i, j].Style.BackColor = Color.White;
                        студентDataGridView[i, j].Style.ForeColor = Color.Black;
                    }
                }
            }
        }
    }
}
