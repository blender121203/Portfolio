﻿
namespace Data_2
{
    partial class Ведомость
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ведомость));
            System.Windows.Forms.Label код_студентаLabel;
            System.Windows.Forms.Label код_предметаLabel;
            System.Windows.Forms.Label дата_сдачиLabel;
            System.Windows.Forms.Label оценкаLabel;
            this.label1 = new System.Windows.Forms.Label();
            this.успеваемостьDataSet = new Data_2.успеваемостьDataSet();
            this.ведомостьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ведомостьTableAdapter = new Data_2.успеваемостьDataSetTableAdapters.ВедомостьTableAdapter();
            this.tableAdapterManager = new Data_2.успеваемостьDataSetTableAdapters.TableAdapterManager();
            this.ведомостьBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.ведомостьBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.код_студентаTextBox = new System.Windows.Forms.TextBox();
            this.код_предметаTextBox = new System.Windows.Forms.TextBox();
            this.дата_сдачиDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.оценкаTextBox = new System.Windows.Forms.TextBox();
            код_студентаLabel = new System.Windows.Forms.Label();
            код_предметаLabel = new System.Windows.Forms.Label();
            дата_сдачиLabel = new System.Windows.Forms.Label();
            оценкаLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.успеваемостьDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ведомостьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ведомостьBindingNavigator)).BeginInit();
            this.ведомостьBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(146, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Общая ведомость";
            // 
            // успеваемостьDataSet
            // 
            this.успеваемостьDataSet.DataSetName = "успеваемостьDataSet";
            this.успеваемостьDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ведомостьBindingSource
            // 
            this.ведомостьBindingSource.DataMember = "Ведомость";
            this.ведомостьBindingSource.DataSource = this.успеваемостьDataSet;
            // 
            // ведомостьTableAdapter
            // 
            this.ведомостьTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = Data_2.успеваемостьDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ВедомостьTableAdapter = this.ведомостьTableAdapter;
            this.tableAdapterManager.ПредметTableAdapter = null;
            this.tableAdapterManager.СтудентTableAdapter = null;
            // 
            // ведомостьBindingNavigator
            // 
            this.ведомостьBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.ведомостьBindingNavigator.BindingSource = this.ведомостьBindingSource;
            this.ведомостьBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.ведомостьBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.ведомостьBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.ведомостьBindingNavigatorSaveItem});
            this.ведомостьBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.ведомостьBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.ведомостьBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.ведомостьBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.ведомостьBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.ведомостьBindingNavigator.Name = "ведомостьBindingNavigator";
            this.ведомостьBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.ведомостьBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.ведомостьBindingNavigator.TabIndex = 11;
            this.ведомостьBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 15);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // ведомостьBindingNavigatorSaveItem
            // 
            this.ведомостьBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ведомостьBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("ведомостьBindingNavigatorSaveItem.Image")));
            this.ведомостьBindingNavigatorSaveItem.Name = "ведомостьBindingNavigatorSaveItem";
            this.ведомостьBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.ведомостьBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.ведомостьBindingNavigatorSaveItem.Click += new System.EventHandler(this.ведомостьBindingNavigatorSaveItem_Click);
            // 
            // код_студентаLabel
            // 
            код_студентаLabel.AutoSize = true;
            код_студентаLabel.Location = new System.Drawing.Point(28, 93);
            код_студентаLabel.Name = "код_студентаLabel";
            код_студентаLabel.Size = new System.Drawing.Size(76, 13);
            код_студентаLabel.TabIndex = 11;
            код_студентаLabel.Text = "код студента:";
            // 
            // код_студентаTextBox
            // 
            this.код_студентаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ведомостьBindingSource, "код студента", true));
            this.код_студентаTextBox.Location = new System.Drawing.Point(110, 90);
            this.код_студентаTextBox.Name = "код_студентаTextBox";
            this.код_студентаTextBox.Size = new System.Drawing.Size(100, 20);
            this.код_студентаTextBox.TabIndex = 12;
            // 
            // код_предметаLabel
            // 
            код_предметаLabel.AutoSize = true;
            код_предметаLabel.Location = new System.Drawing.Point(24, 129);
            код_предметаLabel.Name = "код_предметаLabel";
            код_предметаLabel.Size = new System.Drawing.Size(80, 13);
            код_предметаLabel.TabIndex = 12;
            код_предметаLabel.Text = "код предмета:";
            // 
            // код_предметаTextBox
            // 
            this.код_предметаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ведомостьBindingSource, "код предмета", true));
            this.код_предметаTextBox.Location = new System.Drawing.Point(110, 126);
            this.код_предметаTextBox.Name = "код_предметаTextBox";
            this.код_предметаTextBox.Size = new System.Drawing.Size(100, 20);
            this.код_предметаTextBox.TabIndex = 13;
            // 
            // дата_сдачиLabel
            // 
            дата_сдачиLabel.AutoSize = true;
            дата_сдачиLabel.Location = new System.Drawing.Point(39, 165);
            дата_сдачиLabel.Name = "дата_сдачиLabel";
            дата_сдачиLabel.Size = new System.Drawing.Size(65, 13);
            дата_сдачиLabel.TabIndex = 13;
            дата_сдачиLabel.Text = "дата сдачи:";
            // 
            // дата_сдачиDateTimePicker
            // 
            this.дата_сдачиDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.ведомостьBindingSource, "дата сдачи", true));
            this.дата_сдачиDateTimePicker.Location = new System.Drawing.Point(110, 161);
            this.дата_сдачиDateTimePicker.Name = "дата_сдачиDateTimePicker";
            this.дата_сдачиDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_сдачиDateTimePicker.TabIndex = 14;
            // 
            // оценкаLabel
            // 
            оценкаLabel.AutoSize = true;
            оценкаLabel.Location = new System.Drawing.Point(58, 199);
            оценкаLabel.Name = "оценкаLabel";
            оценкаLabel.Size = new System.Drawing.Size(46, 13);
            оценкаLabel.TabIndex = 14;
            оценкаLabel.Text = "оценка:";
            // 
            // оценкаTextBox
            // 
            this.оценкаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ведомостьBindingSource, "оценка", true));
            this.оценкаTextBox.Location = new System.Drawing.Point(110, 196);
            this.оценкаTextBox.Name = "оценкаTextBox";
            this.оценкаTextBox.Size = new System.Drawing.Size(100, 20);
            this.оценкаTextBox.TabIndex = 15;
            // 
            // Ведомость
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(оценкаLabel);
            this.Controls.Add(this.оценкаTextBox);
            this.Controls.Add(дата_сдачиLabel);
            this.Controls.Add(this.дата_сдачиDateTimePicker);
            this.Controls.Add(код_предметаLabel);
            this.Controls.Add(this.код_предметаTextBox);
            this.Controls.Add(код_студентаLabel);
            this.Controls.Add(this.код_студентаTextBox);
            this.Controls.Add(this.ведомостьBindingNavigator);
            this.Controls.Add(this.label1);
            this.Name = "Ведомость";
            this.Text = "Ведомость";
            this.Load += new System.EventHandler(this.Ведомость_Load);
            ((System.ComponentModel.ISupportInitialize)(this.успеваемостьDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ведомостьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ведомостьBindingNavigator)).EndInit();
            this.ведомостьBindingNavigator.ResumeLayout(false);
            this.ведомостьBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private успеваемостьDataSet успеваемостьDataSet;
        private System.Windows.Forms.BindingSource ведомостьBindingSource;
        private успеваемостьDataSetTableAdapters.ВедомостьTableAdapter ведомостьTableAdapter;
        private успеваемостьDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator ведомостьBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton ведомостьBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox код_студентаTextBox;
        private System.Windows.Forms.TextBox код_предметаTextBox;
        private System.Windows.Forms.DateTimePicker дата_сдачиDateTimePicker;
        private System.Windows.Forms.TextBox оценкаTextBox;
    }
}