﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programm_10
{
    public partial class Form1 : Form
    {
        //Объявление переменных
        #region Peremen
        //Объявление поля класса Form1
        private static double Number1 = 0;// хранение первого числа введенного пользователем
        private static byte Operation = 0;//номер математической операции
        private static double memory = 0;//переменная для кнопок памяти
        //0-сложение
        //1-вычитание
        //2-умножение 
        //3-деление 
        //4-возведение в степень
        //5-mod
        //6-корень n степени
        #endregion
        public Form1()
        {
            InitializeComponent();
        }
        //Методы цифровых кнопок
        #region NumericButtons
        //Кнопка 1
        private void button1_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 1;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "1";
            }
            else
            {
                textBox1.Text += "1";
            }
        }
        //Кнопка 2
        private void button2_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 2;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "2";
            }
            else
            {
                textBox1.Text += "2";
            }
        }
        //Кнопка 3
        private void button3_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 3;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "3";
            }
            else
            {
                textBox1.Text += "3";
            }
        }
        //Кнопка 4
        private void button4_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 4;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "4";
            }
            else
            {
                textBox1.Text += "4";
            }
        }
        //Кнопка 5
        private void button5_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 5;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "5";
            }
            else
            {
                textBox1.Text += "5";
            }
        }
        //Кнопка 6
        private void button6_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 6;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "6";
            }
            else
            {
                textBox1.Text += "6";
            }
        }
        //Кнопка 7
        private void button7_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 7;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "7";
            }
            else
            {
                textBox1.Text += "7";
            }
        }
        //Кнопка 8
        private void button8_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 8;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "8";
            }
            else
            {
                textBox1.Text += "8";
            }
        }
        //Кнопка 9
        private void button9_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            //int Number = int.Parse(textBox1.Text);
            //Получаем новое число
            //Number *= 10;//умножение числа на 10
            //Number += 9;//прибавление требуемую цифру
            //Помещаем результат в textBox
            //textBox1.Text = Number.ToString();
            if (textBox1.Text == "0")
            {
                textBox1.Text = "9";
            }
            else
            {
                textBox1.Text += "9";
            }
        }
        //Кнопка 0
        private void button0_Click(object sender, EventArgs e)
        {
            //Получаем данные из textBox
            int Number = int.Parse(textBox1.Text);
            Number *= 10;//умножение числа на 10
            //Помещаем результат в textBox
            textBox1.Text = Number.ToString();
        }
        #endregion
        //Методы кнопок арифмитических действий
        #region MathOperatins
        //плюс
        private void buttonPlus_Click(object sender, EventArgs e)
        {
            Number1 = double.Parse(textBox1.Text);
            Operation = 0;
            textBox1.Text = "0";
        }
        //минус
        private void buttonMinus_Click(object sender, EventArgs e)
        {
            Number1 = double.Parse(textBox1.Text);
            Operation = 1;
            textBox1.Text = "0";
        }
        //умножение
        private void buttonMaltiply_Click(object sender, EventArgs e)
        {
            Number1 = double.Parse(textBox1.Text);
            Operation = 2;
            textBox1.Text = "0";
        }
        //деление
        private void buttonDivize_Click(object sender, EventArgs e)
        {
            Number1 = double.Parse(textBox1.Text);
            Operation = 3;
            textBox1.Text = "0";
        }
        //плюс-минус
        private void buttonPlusMinus_Click(object sender, EventArgs e)
        {
            //получаем число
            double Number = double.Parse(textBox1.Text);
            //Меяем знак числа
            Number *= -1;
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //Возведение в степень 2
        private void buttonSqr_Click_1(object sender, EventArgs e)
        {
            //получаем число
            double Number = double.Parse(textBox1.Text);
            //Возводим число в степень
            Number = (double)Math.Pow(Number, 2);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }

        //Возведение в степень 3
        private void buttonTrue_Sq_Click_1(object sender, EventArgs e)
        {
            //получаем число
            double Number = double.Parse(textBox1.Text);
            //Возводим число в степень
            Number = (double)Math.Pow(Number, 3);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //Дедение 1 на выбранное число
        private void button10_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            Number = (double)1 / (Number);
            textBox1.Text = Number.ToString();
        }
        //возведение в любую степен
        private void buttonStepen_Click(object sender, EventArgs e)
        {
            Number1 = int.Parse(textBox1.Text);
            textBox1.Text = "0";
            Operation = 4;
        }
        //факториал
        private void buttonFactor_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            double Rezult = 1;
            for (double i = 2; i <= Number; i++)
            {
                Rezult *= i;
            }
            textBox1.Text = Rezult.ToString();
        }
        //Модуль
        private void buttonModul_Click(object sender, EventArgs e)
        {
            //получаем число
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double)Math.Abs(Number);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //Кнопка Пи
        private void buttonPi_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.PI.ToString();//перемещаем число Пи в textBox
        }
        //Корень числа
        private void buttonSqrt_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double)Math.Sqrt(Number);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //Синус
        private void buttonSin_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double)Math.Sin(Number);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //Косинус
        private void buttonCos_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double)Math.Cos(Number);
            //Выводим результат
            textBox1.Text =Number.ToString();
        }
        //Тангенс
        private void buttonTg_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double) Math.Tan(Number);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        // Обработка Е
        private void buttonE_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.E.ToString();
        }
        //Логорифм
        private void buttonLog_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double)Math.Log(Number);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //Десятичный логарифм
        private void buttonIn_Click(object sender, EventArgs e)
        {
            //получаем число
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double)Math.Log10(Number);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //EXP
        private void buttonEXP_Click(object sender, EventArgs e)
        {
            //получаем число
            double Number = double.Parse(textBox1.Text);
            //Возведение в модуль
            Number = (double)Math.Exp(Number);
            //Выводим результат
            textBox1.Text = Number.ToString();
        }
        //Запятая
        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.Contains(',') ? textBox1.Text : textBox1.Text + ',';
        }
        #endregion
        //Кнопки паямти
        #region Payamti buttons
        //M
        private void buttonM_Click(object sender, EventArgs e)
        {
            double Number = double.Parse(textBox1.Text);
            memory = Number;
            textBox1.Text = "0";
        }
        //MR
        private void buttonMR_Click(object sender, EventArgs e)
        {
            textBox1.Text = memory.ToString();
        }
        //Копка отчистки памяти
        private void buttonMC_Click(object sender, EventArgs e)
        {
            memory = 0;
        }
        //Кнопка C
        private void buttonC_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            memory = 0;
        }
        //Кнопка CE
        private void buttonCE_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }
        //Backspace
        private void buttonBackspace_Click(object sender, EventArgs e)
        {
            StringBuilder stroka = new StringBuilder(textBox1.Text);
            stroka.Remove(stroka.Length - 1, 1);
            if (stroka.ToString() == "")
                stroka = new StringBuilder("0");
            textBox1.Text = stroka.ToString();
        }
        #endregion
        //Равно
        #region Rezult
        private void buttonRezult_Click(object sender, EventArgs e)
        {
            double Number2 = double.Parse(textBox1.Text);
            switch (Operation)
            {
                case 0:
                    Number2 += Number1;
                    break;
                case 1:
                    Number2 = Number1 - Number2;
                    break;
                case 2:
                    Number2 = Number1 * Number2;
                    break;
                case 3:
                    Number2 = Number1 / Number2;
                    break;
                case 4:
                    Number2 = (long)Math.Pow(Number1, Number2);
                    break;
                case 5:
                    Number2 = Number1 % Number2;
                    break;
                case 6:
                    Number2 = (long)Math.Pow(Number1, 1 / Number2);
                    break;
            }
            textBox1.Text = Number2.ToString();
        }
        #endregion
        //Введение цифр с клавиатуры
        #region KeyPress
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //цифры
            char symbol = e.KeyChar;
            switch (symbol)
            {
                case '1':
                    button1_Click(button1, null);
                    break;
                case '2':
                    button2_Click(button2, null);
                    break;
                case '3':
                    button3_Click(button3, null); 
                    break;
                case '4':
                    button4_Click(button4, null);
                    break;
                case '5':
                    button5_Click(button5, null);
                    break;
                case '6':
                    button6_Click(button6, null);
                    break;
                case '7':
                    button7_Click(button7, null);
                    break;
                case '8':
                    button8_Click(button8, null);
                    break;
                case '9':
                    button9_Click(button9, null);
                    break;
                case '0':
                    button0_Click(button0, null);
                    break;
                case '+':
                    buttonPlus_Click(buttonPlus, null);
                    break;
                case '-':
                    buttonMinus_Click(buttonMinus, null);
                    break;
                case '*':
                    buttonMaltiply_Click(buttonMaltiply, null);
                    break;
                case '/':
                    buttonDivize_Click(buttonDivize, null);
                    break;
                case 'q':
                    buttonSqrt_Click(buttonSqrt, null);

                    break;
                case 'w':
                    buttonSqr_Click_1(buttonSqr, null);

                    break;
                case 'g':
                    buttonTrue_Sq_Click_1(buttonTrue_Sq, null);

                    break;
                case '!':
                    buttonFactor_Click(buttonFactor, null);

                    break;
                case ',':
                case '.':
                    button11_Click(button11, null);

                    break;
                case 's':
                    buttonSin_Click(buttonSin, null);

                    break;
                case 'c':
                    buttonCos_Click(buttonCos, null);

                    break;
                case 'π':
                    buttonPi_Click(buttonPi, null);

                    break;
                case 'e':
                    buttonE_Click(buttonE, null);

                    break;
                case 't':
                    buttonTg_Click(buttonTg, null);

                    break;
                case '=':
                    buttonRezult_Click(buttonRezult, null);

                    break;
                case 'M':
                    buttonM_Click(buttonM, null);
                    break;
                case 'R':
                    buttonMR_Click(buttonMR, null);
                    break;
                case 'C':
                    buttonMC_Click(buttonMC, null);
                    break;
                case 'L':
                    buttonLog_Click(buttonLog, null);
                    break;
                case 'n':
                    buttonIn_Click(buttonIn, null);
                    break;
                case 'd':
                    buttonModul_Click(buttonModul, null);
                    break;
                case 'z':
                    button10_Click(button10, null);
                    break;
                case 'x':
                    buttonEXP_Click(buttonEXP, null);
                    break;
            }
        }
            #endregion
        //Введение редактирующих кнопок с клавиатуры
        #region KeyDown

            private void From1_KeyDown(object sender, KeyEventArgs e)
            {
                switch (e.KeyCode)
                {
                    case Keys.Back:
                        buttonBackspace_Click(buttonBackspace, null);
                        break;
                    case Keys.Escape:
                        buttonCE_Click(buttonCE, null);
                        break;
                    case Keys.Delete:
                        buttonC_Click(buttonC, null);
                        break;
                }
                //Дополнительные кнопки

            }
            #endregion
        //добавленные кнопки
        #region Added buttons
            private void buttonProqent_Click(object sender, EventArgs e)
            {
                 double Number = double.Parse(textBox1.Text);
                //Возведение в модуль
                Number = (double)Number / 100;
                //Выводим результат
                textBox1.Text = Number.ToString();
            }
            //Остаток отделения
            private void buttonMod_Click(object sender, EventArgs e)
            {
                Number1 = double.Parse(textBox1.Text);
                Operation = 5;
                textBox1.Text = "0";
            }
            //Крень n - степени
            private void buttonSqrxy_Click(object sender, EventArgs e)
            {
                Number1 = double.Parse(textBox1.Text);
                Operation = 6;
                textBox1.Text = "0";
            }
            #endregion
    }
}