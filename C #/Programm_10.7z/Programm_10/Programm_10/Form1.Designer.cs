﻿
namespace Programm_10
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.buttonPlus = new System.Windows.Forms.Button();
            this.buttonMinus = new System.Windows.Forms.Button();
            this.buttonMaltiply = new System.Windows.Forms.Button();
            this.buttonDivize = new System.Windows.Forms.Button();
            this.buttonRezult = new System.Windows.Forms.Button();
            this.buttonPlusMinus = new System.Windows.Forms.Button();
            this.buttonFactor = new System.Windows.Forms.Button();
            this.buttonModul = new System.Windows.Forms.Button();
            this.buttonStepen = new System.Windows.Forms.Button();
            this.buttonSqr = new System.Windows.Forms.Button();
            this.buttonTrue_Sq = new System.Windows.Forms.Button();
            this.buttonPi = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.buttonSqrt = new System.Windows.Forms.Button();
            this.buttonSin = new System.Windows.Forms.Button();
            this.buttonCos = new System.Windows.Forms.Button();
            this.buttonTg = new System.Windows.Forms.Button();
            this.buttonEXP = new System.Windows.Forms.Button();
            this.buttonIn = new System.Windows.Forms.Button();
            this.buttonLog = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonMC = new System.Windows.Forms.Button();
            this.buttonMR = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonBackspace = new System.Windows.Forms.Button();
            this.buttonCE = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.buttonMod = new System.Windows.Forms.Button();
            this.buttonSqrxy = new System.Windows.Forms.Button();
            this.buttonProqent = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkBlue;
            this.textBox1.Location = new System.Drawing.Point(31, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(331, 29);
            this.textBox1.TabIndex = 0;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.From1_KeyDown);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button1.Location = new System.Drawing.Point(31, 85);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "1";
            this.toolTip1.SetToolTip(this.button1, "Один");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button2.Location = new System.Drawing.Point(117, 85);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 50);
            this.button2.TabIndex = 2;
            this.button2.Text = "2";
            this.toolTip1.SetToolTip(this.button2, "Два");
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            this.button2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button3.Location = new System.Drawing.Point(207, 85);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(50, 50);
            this.button3.TabIndex = 3;
            this.button3.Text = "3";
            this.toolTip1.SetToolTip(this.button3, "Три");
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            this.button3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button4.Location = new System.Drawing.Point(31, 175);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(50, 50);
            this.button4.TabIndex = 6;
            this.button4.Text = "4";
            this.toolTip1.SetToolTip(this.button4, "Четыре");
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button5.Location = new System.Drawing.Point(117, 175);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 50);
            this.button5.TabIndex = 5;
            this.button5.Text = "5";
            this.toolTip1.SetToolTip(this.button5, "Пять");
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            this.button5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button6.Location = new System.Drawing.Point(207, 175);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 50);
            this.button6.TabIndex = 4;
            this.button6.Text = "6";
            this.toolTip1.SetToolTip(this.button6, "Шесть");
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            this.button6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button7.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button7.Location = new System.Drawing.Point(31, 267);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(50, 50);
            this.button7.TabIndex = 9;
            this.button7.Text = "7";
            this.toolTip1.SetToolTip(this.button7, "Семь");
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            this.button7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button8.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button8.Location = new System.Drawing.Point(117, 267);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(50, 50);
            this.button8.TabIndex = 8;
            this.button8.Text = "8";
            this.toolTip1.SetToolTip(this.button8, "Восемь");
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            this.button8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button9.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button9.Location = new System.Drawing.Point(207, 267);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(50, 50);
            this.button9.TabIndex = 7;
            this.button9.Text = "9";
            this.toolTip1.SetToolTip(this.button9, "Девять");
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            this.button9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button0.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button0.Location = new System.Drawing.Point(31, 350);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(50, 50);
            this.button0.TabIndex = 10;
            this.button0.Text = "0";
            this.toolTip1.SetToolTip(this.button0, "Ноль");
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            this.button0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonPlus
            // 
            this.buttonPlus.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPlus.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonPlus.Location = new System.Drawing.Point(287, 85);
            this.buttonPlus.Name = "buttonPlus";
            this.buttonPlus.Size = new System.Drawing.Size(75, 50);
            this.buttonPlus.TabIndex = 11;
            this.buttonPlus.Text = "+";
            this.toolTip1.SetToolTip(this.buttonPlus, "Плюс");
            this.buttonPlus.UseVisualStyleBackColor = false;
            this.buttonPlus.Click += new System.EventHandler(this.buttonPlus_Click);
            this.buttonPlus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonMinus
            // 
            this.buttonMinus.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMinus.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonMinus.Location = new System.Drawing.Point(287, 175);
            this.buttonMinus.Name = "buttonMinus";
            this.buttonMinus.Size = new System.Drawing.Size(75, 50);
            this.buttonMinus.TabIndex = 12;
            this.buttonMinus.Text = "-";
            this.toolTip1.SetToolTip(this.buttonMinus, "Минус");
            this.buttonMinus.UseVisualStyleBackColor = false;
            this.buttonMinus.Click += new System.EventHandler(this.buttonMinus_Click);
            this.buttonMinus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonMaltiply
            // 
            this.buttonMaltiply.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonMaltiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMaltiply.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonMaltiply.Location = new System.Drawing.Point(287, 267);
            this.buttonMaltiply.Name = "buttonMaltiply";
            this.buttonMaltiply.Size = new System.Drawing.Size(75, 50);
            this.buttonMaltiply.TabIndex = 13;
            this.buttonMaltiply.Text = "*";
            this.toolTip1.SetToolTip(this.buttonMaltiply, "Умножить");
            this.buttonMaltiply.UseVisualStyleBackColor = false;
            this.buttonMaltiply.Click += new System.EventHandler(this.buttonMaltiply_Click);
            this.buttonMaltiply.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonDivize
            // 
            this.buttonDivize.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonDivize.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDivize.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonDivize.Location = new System.Drawing.Point(287, 350);
            this.buttonDivize.Name = "buttonDivize";
            this.buttonDivize.Size = new System.Drawing.Size(75, 50);
            this.buttonDivize.TabIndex = 14;
            this.buttonDivize.Text = "/";
            this.toolTip1.SetToolTip(this.buttonDivize, "Разделить");
            this.buttonDivize.UseVisualStyleBackColor = false;
            this.buttonDivize.Click += new System.EventHandler(this.buttonDivize_Click);
            this.buttonDivize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonRezult
            // 
            this.buttonRezult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonRezult.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonRezult.ForeColor = System.Drawing.Color.DarkMagenta;
            this.buttonRezult.Location = new System.Drawing.Point(117, 350);
            this.buttonRezult.Name = "buttonRezult";
            this.buttonRezult.Size = new System.Drawing.Size(50, 50);
            this.buttonRezult.TabIndex = 15;
            this.buttonRezult.Text = "=";
            this.toolTip1.SetToolTip(this.buttonRezult, "Равно");
            this.buttonRezult.UseVisualStyleBackColor = false;
            this.buttonRezult.Click += new System.EventHandler(this.buttonRezult_Click);
            this.buttonRezult.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonPlusMinus
            // 
            this.buttonPlusMinus.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonPlusMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPlusMinus.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonPlusMinus.Location = new System.Drawing.Point(395, 85);
            this.buttonPlusMinus.Name = "buttonPlusMinus";
            this.buttonPlusMinus.Size = new System.Drawing.Size(75, 50);
            this.buttonPlusMinus.TabIndex = 16;
            this.buttonPlusMinus.Text = "+/-";
            this.toolTip1.SetToolTip(this.buttonPlusMinus, "Положительное или отрицательное число");
            this.buttonPlusMinus.UseVisualStyleBackColor = false;
            this.buttonPlusMinus.Click += new System.EventHandler(this.buttonPlusMinus_Click);
            this.buttonPlusMinus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonFactor
            // 
            this.buttonFactor.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonFactor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonFactor.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonFactor.Location = new System.Drawing.Point(503, 85);
            this.buttonFactor.Name = "buttonFactor";
            this.buttonFactor.Size = new System.Drawing.Size(75, 50);
            this.buttonFactor.TabIndex = 18;
            this.buttonFactor.Text = "n!";
            this.toolTip1.SetToolTip(this.buttonFactor, "Факториал числа");
            this.buttonFactor.UseVisualStyleBackColor = false;
            this.buttonFactor.Click += new System.EventHandler(this.buttonFactor_Click);
            this.buttonFactor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonModul
            // 
            this.buttonModul.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonModul.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonModul.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonModul.Location = new System.Drawing.Point(503, 175);
            this.buttonModul.Name = "buttonModul";
            this.buttonModul.Size = new System.Drawing.Size(75, 50);
            this.buttonModul.TabIndex = 19;
            this.buttonModul.Text = "|x|";
            this.toolTip1.SetToolTip(this.buttonModul, "Модуль числа");
            this.buttonModul.UseVisualStyleBackColor = false;
            this.buttonModul.Click += new System.EventHandler(this.buttonModul_Click);
            this.buttonModul.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonStepen
            // 
            this.buttonStepen.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonStepen.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonStepen.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonStepen.Location = new System.Drawing.Point(395, 350);
            this.buttonStepen.Name = "buttonStepen";
            this.buttonStepen.Size = new System.Drawing.Size(75, 50);
            this.buttonStepen.TabIndex = 21;
            this.buttonStepen.Text = "xʸ";
            this.toolTip1.SetToolTip(this.buttonStepen, "Возведение в заданною польхователем степеннь");
            this.buttonStepen.UseVisualStyleBackColor = false;
            this.buttonStepen.Click += new System.EventHandler(this.buttonStepen_Click);
            this.buttonStepen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonSqr
            // 
            this.buttonSqr.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonSqr.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSqr.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonSqr.Location = new System.Drawing.Point(395, 175);
            this.buttonSqr.Name = "buttonSqr";
            this.buttonSqr.Size = new System.Drawing.Size(75, 50);
            this.buttonSqr.TabIndex = 22;
            this.buttonSqr.Text = "x²";
            this.toolTip1.SetToolTip(this.buttonSqr, "Возведение во вторую сепень");
            this.buttonSqr.UseVisualStyleBackColor = false;
            this.buttonSqr.Click += new System.EventHandler(this.buttonSqr_Click_1);
            this.buttonSqr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonTrue_Sq
            // 
            this.buttonTrue_Sq.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonTrue_Sq.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonTrue_Sq.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonTrue_Sq.Location = new System.Drawing.Point(395, 267);
            this.buttonTrue_Sq.Name = "buttonTrue_Sq";
            this.buttonTrue_Sq.Size = new System.Drawing.Size(75, 50);
            this.buttonTrue_Sq.TabIndex = 24;
            this.buttonTrue_Sq.Text = "x³";
            this.toolTip1.SetToolTip(this.buttonTrue_Sq, "Возведение в третью степень");
            this.buttonTrue_Sq.UseVisualStyleBackColor = false;
            this.buttonTrue_Sq.Click += new System.EventHandler(this.buttonTrue_Sq_Click_1);
            this.buttonTrue_Sq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonPi
            // 
            this.buttonPi.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonPi.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPi.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonPi.Location = new System.Drawing.Point(503, 267);
            this.buttonPi.Name = "buttonPi";
            this.buttonPi.Size = new System.Drawing.Size(75, 50);
            this.buttonPi.TabIndex = 25;
            this.buttonPi.Text = "π";
            this.toolTip1.SetToolTip(this.buttonPi, "Число пи");
            this.buttonPi.UseVisualStyleBackColor = false;
            this.buttonPi.Click += new System.EventHandler(this.buttonPi_Click);
            this.buttonPi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button10.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button10.ForeColor = System.Drawing.Color.DarkBlue;
            this.button10.Location = new System.Drawing.Point(503, 350);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 50);
            this.button10.TabIndex = 26;
            this.button10.Text = "1/x";
            this.toolTip1.SetToolTip(this.button10, "Деление еденицы на веденое число");
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            this.button10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonSqrt
            // 
            this.buttonSqrt.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonSqrt.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSqrt.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonSqrt.Location = new System.Drawing.Point(610, 85);
            this.buttonSqrt.Name = "buttonSqrt";
            this.buttonSqrt.Size = new System.Drawing.Size(75, 50);
            this.buttonSqrt.TabIndex = 27;
            this.buttonSqrt.Text = "√x";
            this.toolTip1.SetToolTip(this.buttonSqrt, "Корень ");
            this.buttonSqrt.UseVisualStyleBackColor = false;
            this.buttonSqrt.Click += new System.EventHandler(this.buttonSqrt_Click);
            this.buttonSqrt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonSin
            // 
            this.buttonSin.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonSin.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSin.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonSin.Location = new System.Drawing.Point(610, 175);
            this.buttonSin.Name = "buttonSin";
            this.buttonSin.Size = new System.Drawing.Size(75, 50);
            this.buttonSin.TabIndex = 28;
            this.buttonSin.Text = "sin";
            this.toolTip1.SetToolTip(this.buttonSin, "Синус");
            this.buttonSin.UseVisualStyleBackColor = false;
            this.buttonSin.Click += new System.EventHandler(this.buttonSin_Click);
            this.buttonSin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonCos
            // 
            this.buttonCos.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonCos.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCos.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonCos.Location = new System.Drawing.Point(610, 267);
            this.buttonCos.Name = "buttonCos";
            this.buttonCos.Size = new System.Drawing.Size(75, 50);
            this.buttonCos.TabIndex = 29;
            this.buttonCos.Text = "cos";
            this.toolTip1.SetToolTip(this.buttonCos, "Косинус");
            this.buttonCos.UseVisualStyleBackColor = false;
            this.buttonCos.Click += new System.EventHandler(this.buttonCos_Click);
            this.buttonCos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonTg
            // 
            this.buttonTg.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonTg.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonTg.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonTg.Location = new System.Drawing.Point(610, 350);
            this.buttonTg.Name = "buttonTg";
            this.buttonTg.Size = new System.Drawing.Size(75, 50);
            this.buttonTg.TabIndex = 30;
            this.buttonTg.Text = "tg";
            this.toolTip1.SetToolTip(this.buttonTg, "Тангенс");
            this.buttonTg.UseVisualStyleBackColor = false;
            this.buttonTg.Click += new System.EventHandler(this.buttonTg_Click);
            this.buttonTg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonEXP
            // 
            this.buttonEXP.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonEXP.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEXP.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonEXP.Location = new System.Drawing.Point(716, 350);
            this.buttonEXP.Name = "buttonEXP";
            this.buttonEXP.Size = new System.Drawing.Size(75, 50);
            this.buttonEXP.TabIndex = 34;
            this.buttonEXP.Text = "exp";
            this.toolTip1.SetToolTip(this.buttonEXP, "Обратная функция вычисления логарифма");
            this.buttonEXP.UseVisualStyleBackColor = false;
            this.buttonEXP.Click += new System.EventHandler(this.buttonEXP_Click);
            this.buttonEXP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonIn
            // 
            this.buttonIn.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonIn.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonIn.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonIn.Location = new System.Drawing.Point(716, 267);
            this.buttonIn.Name = "buttonIn";
            this.buttonIn.Size = new System.Drawing.Size(75, 50);
            this.buttonIn.TabIndex = 33;
            this.buttonIn.Text = "ln";
            this.toolTip1.SetToolTip(this.buttonIn, "Десятичный логарифм");
            this.buttonIn.UseVisualStyleBackColor = false;
            this.buttonIn.Click += new System.EventHandler(this.buttonIn_Click);
            this.buttonIn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonLog
            // 
            this.buttonLog.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonLog.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonLog.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonLog.Location = new System.Drawing.Point(716, 175);
            this.buttonLog.Name = "buttonLog";
            this.buttonLog.Size = new System.Drawing.Size(75, 50);
            this.buttonLog.TabIndex = 32;
            this.buttonLog.Text = "log";
            this.toolTip1.SetToolTip(this.buttonLog, "Логорифм числа");
            this.buttonLog.UseVisualStyleBackColor = false;
            this.buttonLog.Click += new System.EventHandler(this.buttonLog_Click);
            this.buttonLog.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonE
            // 
            this.buttonE.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonE.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonE.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonE.Location = new System.Drawing.Point(716, 85);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(75, 50);
            this.buttonE.TabIndex = 31;
            this.buttonE.Text = "e";
            this.toolTip1.SetToolTip(this.buttonE, "Число Е");
            this.buttonE.UseVisualStyleBackColor = false;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            this.buttonE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonMC
            // 
            this.buttonMC.BackColor = System.Drawing.Color.Aqua;
            this.buttonMC.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMC.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonMC.Location = new System.Drawing.Point(823, 350);
            this.buttonMC.Name = "buttonMC";
            this.buttonMC.Size = new System.Drawing.Size(75, 50);
            this.buttonMC.TabIndex = 37;
            this.buttonMC.Text = "MC";
            this.toolTip1.SetToolTip(this.buttonMC, "Кнопка отчистки памяти");
            this.buttonMC.UseVisualStyleBackColor = false;
            this.buttonMC.Click += new System.EventHandler(this.buttonMC_Click);
            this.buttonMC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonMR
            // 
            this.buttonMR.BackColor = System.Drawing.Color.Aqua;
            this.buttonMR.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMR.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonMR.Location = new System.Drawing.Point(823, 267);
            this.buttonMR.Name = "buttonMR";
            this.buttonMR.Size = new System.Drawing.Size(75, 50);
            this.buttonMR.TabIndex = 36;
            this.buttonMR.Text = "MR";
            this.toolTip1.SetToolTip(this.buttonMR, " отображает текущее содержимое буфера");
            this.buttonMR.UseVisualStyleBackColor = false;
            this.buttonMR.Click += new System.EventHandler(this.buttonMR_Click);
            this.buttonMR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonM
            // 
            this.buttonM.BackColor = System.Drawing.Color.Aqua;
            this.buttonM.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonM.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonM.Location = new System.Drawing.Point(823, 177);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(75, 50);
            this.buttonM.TabIndex = 35;
            this.buttonM.Text = "M";
            this.toolTip1.SetToolTip(this.buttonM, "Запись числа в память");
            this.buttonM.UseVisualStyleBackColor = false;
            this.buttonM.Click += new System.EventHandler(this.buttonM_Click);
            this.buttonM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonC
            // 
            this.buttonC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonC.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonC.Location = new System.Drawing.Point(395, 13);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(75, 50);
            this.buttonC.TabIndex = 38;
            this.buttonC.Text = "C";
            this.toolTip1.SetToolTip(this.buttonC, "Отчисть и память и поле");
            this.buttonC.UseVisualStyleBackColor = false;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            this.buttonC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.From1_KeyDown);
            this.buttonC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonBackspace
            // 
            this.buttonBackspace.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonBackspace.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackspace.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonBackspace.Location = new System.Drawing.Point(610, 12);
            this.buttonBackspace.Name = "buttonBackspace";
            this.buttonBackspace.Size = new System.Drawing.Size(75, 50);
            this.buttonBackspace.TabIndex = 39;
            this.buttonBackspace.Text = "←";
            this.toolTip1.SetToolTip(this.buttonBackspace, "Удалять по одному символу");
            this.buttonBackspace.UseVisualStyleBackColor = false;
            this.buttonBackspace.Click += new System.EventHandler(this.buttonBackspace_Click);
            this.buttonBackspace.KeyDown += new System.Windows.Forms.KeyEventHandler(this.From1_KeyDown);
            this.buttonBackspace.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // buttonCE
            // 
            this.buttonCE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonCE.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCE.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonCE.Location = new System.Drawing.Point(503, 12);
            this.buttonCE.Name = "buttonCE";
            this.buttonCE.Size = new System.Drawing.Size(75, 50);
            this.buttonCE.TabIndex = 40;
            this.buttonCE.Text = "CE";
            this.toolTip1.SetToolTip(this.buttonCE, "Отчистить поле");
            this.buttonCE.UseVisualStyleBackColor = false;
            this.buttonCE.Click += new System.EventHandler(this.buttonCE_Click);
            this.buttonCE.KeyDown += new System.Windows.Forms.KeyEventHandler(this.From1_KeyDown);
            this.buttonCE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button11.ForeColor = System.Drawing.Color.DarkMagenta;
            this.button11.Location = new System.Drawing.Point(207, 349);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(50, 50);
            this.button11.TabIndex = 41;
            this.button11.Text = ",";
            this.toolTip1.SetToolTip(this.button11, "Запятая");
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            this.button11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // toolTip1
            // 
            this.toolTip1.ForeColor = System.Drawing.Color.Black;
            this.toolTip1.IsBalloon = true;
            // 
            // buttonMod
            // 
            this.buttonMod.BackColor = System.Drawing.Color.Azure;
            this.buttonMod.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMod.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonMod.Location = new System.Drawing.Point(823, 14);
            this.buttonMod.Name = "buttonMod";
            this.buttonMod.Size = new System.Drawing.Size(75, 50);
            this.buttonMod.TabIndex = 42;
            this.buttonMod.Text = "Mod";
            this.toolTip1.SetToolTip(this.buttonMod, "Обратная функция вычисления логарифма");
            this.buttonMod.UseVisualStyleBackColor = false;
            this.buttonMod.Click += new System.EventHandler(this.buttonMod_Click);
            // 
            // buttonSqrxy
            // 
            this.buttonSqrxy.BackColor = System.Drawing.Color.Azure;
            this.buttonSqrxy.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSqrxy.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonSqrxy.Location = new System.Drawing.Point(823, 85);
            this.buttonSqrxy.Name = "buttonSqrxy";
            this.buttonSqrxy.Size = new System.Drawing.Size(75, 50);
            this.buttonSqrxy.TabIndex = 43;
            this.buttonSqrxy.Text = "ʸ√x";
            this.toolTip1.SetToolTip(this.buttonSqrxy, "Число Е");
            this.buttonSqrxy.UseVisualStyleBackColor = false;
            this.buttonSqrxy.Click += new System.EventHandler(this.buttonSqrxy_Click);
            // 
            // buttonProqent
            // 
            this.buttonProqent.BackColor = System.Drawing.Color.Azure;
            this.buttonProqent.Font = new System.Drawing.Font("Times New Roman", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonProqent.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonProqent.Location = new System.Drawing.Point(716, 12);
            this.buttonProqent.Name = "buttonProqent";
            this.buttonProqent.Size = new System.Drawing.Size(75, 50);
            this.buttonProqent.TabIndex = 44;
            this.buttonProqent.Text = "%";
            this.toolTip1.SetToolTip(this.buttonProqent, "Число Е");
            this.buttonProqent.UseVisualStyleBackColor = false;
            this.buttonProqent.Click += new System.EventHandler(this.buttonProqent_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 438);
            this.Controls.Add(this.buttonProqent);
            this.Controls.Add(this.buttonSqrxy);
            this.Controls.Add(this.buttonMod);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.buttonCE);
            this.Controls.Add(this.buttonBackspace);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.buttonMC);
            this.Controls.Add(this.buttonMR);
            this.Controls.Add(this.buttonM);
            this.Controls.Add(this.buttonEXP);
            this.Controls.Add(this.buttonIn);
            this.Controls.Add(this.buttonLog);
            this.Controls.Add(this.buttonE);
            this.Controls.Add(this.buttonTg);
            this.Controls.Add(this.buttonCos);
            this.Controls.Add(this.buttonSin);
            this.Controls.Add(this.buttonSqrt);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.buttonPi);
            this.Controls.Add(this.buttonTrue_Sq);
            this.Controls.Add(this.buttonStepen);
            this.Controls.Add(this.buttonSqr);
            this.Controls.Add(this.buttonModul);
            this.Controls.Add(this.buttonFactor);
            this.Controls.Add(this.buttonPlusMinus);
            this.Controls.Add(this.buttonRezult);
            this.Controls.Add(this.buttonDivize);
            this.Controls.Add(this.buttonMaltiply);
            this.Controls.Add(this.buttonMinus);
            this.Controls.Add(this.buttonPlus);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.From1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button buttonPlus;
        private System.Windows.Forms.Button buttonMinus;
        private System.Windows.Forms.Button buttonMaltiply;
        private System.Windows.Forms.Button buttonDivize;
        private System.Windows.Forms.Button buttonRezult;
        private System.Windows.Forms.Button buttonPlusMinus;
        private System.Windows.Forms.Button buttonFactor;
        private System.Windows.Forms.Button buttonModul;
        private System.Windows.Forms.Button buttonStepen;
        private System.Windows.Forms.Button buttonSqr;
        private System.Windows.Forms.Button buttonTrue_Sq;
        private System.Windows.Forms.Button buttonPi;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button buttonSqrt;
        private System.Windows.Forms.Button buttonSin;
        private System.Windows.Forms.Button buttonCos;
        private System.Windows.Forms.Button buttonTg;
        private System.Windows.Forms.Button buttonEXP;
        private System.Windows.Forms.Button buttonIn;
        private System.Windows.Forms.Button buttonLog;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonMC;
        private System.Windows.Forms.Button buttonMR;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonBackspace;
        private System.Windows.Forms.Button buttonCE;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button buttonMod;
        private System.Windows.Forms.Button buttonSqrxy;
        private System.Windows.Forms.Button buttonProqent;
    }
}

